package exercise01;

public class Order {

	private Customer customer;
	// TODO: find a way to store multiple Items

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/**
	 * Removes <b>all</b> items from this order that have a specific id.
	 * 
	 * @param id
	 *            The id to be removed.
	 */
	public void removeItemWithId(int id) {
		// TODO: implement this method
	}

	/**
	 * Adds an {@code item} {@code amount} times to this order, regardless of it
	 * being part of it already.
	 * 
	 * @param item
	 *            The item to be added to this order
	 * @param amount
	 *            The amount of times that the item is to be added.
	 */
	public void addItem(Item item, int amount) {
		// TODO: implement this method
	}

	/**
	 * Returns the total sum of this order. The sum consists of the price of each
	 * item in this order. Items added multiple times will also contribute to the
	 * sum multiple times accordingly.
	 * 
	 * @return The sum of all prices of each item in this order.
	 */
	public float getTotal() {
		// TODO: implement this method
		return 0f;
	}

	/**
	 * Returns the average price of an item in this order. The average is calculated
	 * by dividing the total sum by the amount of items in this order.
	 * 
	 * @return The average price of an item in this order.
	 */
	public float getAveragePrice() {
		// TODO: implement this method
		return 0f;
	}

	// TODO: find a way to make the output from the main method prettier.

}
