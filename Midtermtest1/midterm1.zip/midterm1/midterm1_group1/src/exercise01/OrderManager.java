package exercise01;

import java.util.ArrayList;
import java.util.List;

public class OrderManager {

	public static void main(String[] args) {
		
		// DO NOT CHANGE THIS CLASS
		
		Customer c1 = new Customer(12, "John", "Smith");
		Customer c2 = new Customer(13, "Mary", "James");
		
		Item i1 = new Item(2, "stapler", 23.50f);
		Item i2 = new Item(3, "hole punch", 16.90f);
		Item i3 = new Item(4, "paperclip", 0.01f);
		List<Item> items = new ArrayList<>();
		items.add(i1);
		items.add(i2);
		items.add(i3);
		
		Order o1 = new Order();
		int amount = 4;
		o1.addItem(i1, amount);
		o1.setCustomer(c1);
		System.out.println(o1);
		
		Order o2 = new Order();
		for (int i=0; i<items.size(); i++) {
			o2.addItem(items.get(i), i+2);
		}
		o2.removeItemWithId(3);
		o2.setCustomer(c2);
		System.out.println(o2);
				
	}
	
}
