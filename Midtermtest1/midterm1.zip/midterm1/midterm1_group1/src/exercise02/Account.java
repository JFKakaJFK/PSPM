package exercise02;

public interface Account {

	public double getCurrentAmount();
	
	public void deposit(double amount);
	
	public void withdraw(double amount);
	
	public void transfer(Account other, double amount);
	
}
