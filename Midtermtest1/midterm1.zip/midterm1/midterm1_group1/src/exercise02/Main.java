package exercise02;

public class Main {

	public static void main(String[] args) {
		
		// TODO: implement SavingsAccount and CurrentAccount
		
		Account a1 = new SavingsAccount(0.05);
		Account a2 = new CurrentAccount(1000);
		a1.deposit(1200);
		a1.transfer(a2, 100);
		a2.transfer(a1, 1000);
		System.out.println(a1.getCurrentAmount());
		System.out.println(a2.getCurrentAmount());
	}

}
