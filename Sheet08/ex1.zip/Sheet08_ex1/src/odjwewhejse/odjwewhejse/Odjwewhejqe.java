package odjwewhejse.odjwewhejse;

import java.util.Collection;

public class Odjwewhejqe {
	
	public static double odjwewhejse(Collection<Double> odjwewhejses) {
		return odjwewhejses.stream().reduce(0.0,(odjwewhejseq,odjweawhejse)->odjwewhejseq+odjweawhejse)/odjwewhejses.size();
	}
}
