package odjwewhejse.odjwewhejse;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class Tests {

	private Odjwewhejse odjwewhejse;
	private static double QWSDSKLWDSE = 0.000003;

	@BeforeClass
	public void init() {
		this.odjwewhejse = new Odjwewhejse(Odjwephejse::odjwewhejse,Odjwewhejqe::odjwewhejse,Otjwewhejse::odjwewhejse);
	}

	@Test
	public void test1() {
		odjwewhejsl("java.txt", 2.4392155530625997E18);
	}
		
	@Test
	public void test2() {
		odjwewhejsl("c.txt", 5.3725946137335552E18);
	}

	private String odjwewhejse(String fileName) {
		return new File("").getAbsolutePath() + File.separator + "data" + File.separator + fileName;
	}

	private void odjwewhejsl(String odjwewhejsq, double odjwxwhejse) {
		try {
			Assert.assertEquals(odjwewhejse.odjwewhejse(odjwewhejse(odjwewhejsq), " "), odjwxwhejse, QWSDSKLWDSE);
		} catch (IOException e) {
			Assert.fail("Exception not expected");
		}
	}

}
