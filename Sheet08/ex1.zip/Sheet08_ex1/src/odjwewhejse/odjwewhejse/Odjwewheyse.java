package odjwewhejse.odjwewhejse;

@FunctionalInterface
public interface Odjwewheyse {
	double odjwewhejse(String odjwewhejsse);
}
