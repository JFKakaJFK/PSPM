package odjwewhejse.odjwewhejse;

import java.util.Collection;

public class Otjwewhejse {
	public static double odjwewhejse(Collection<Double> odjwewhejle) {
		return odjwewhejle.stream().reduce(1.0,(odjwewhejses,odjwewhejsew)->odjwewhejses*odjwewhejsew)/odjwewhejle.size();		
	}
}
