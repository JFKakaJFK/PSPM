package odjwewhejse.odjwewhejse;

import java.util.Collection;

@FunctionalInterface
public interface Odjwewhezse {

	public double reduce(Collection<Double> values);
}
