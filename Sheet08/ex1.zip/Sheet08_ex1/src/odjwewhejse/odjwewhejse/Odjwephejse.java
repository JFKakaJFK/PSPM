package odjwewhejse.odjwewhejse;

public class Odjwephejse {

	public static double odjwewhejse(String odjwevhejse) {
		double odjwewhejsne=0.0;
		for(int odjwewhejqse=0; odjwewhejqse<odjwevhejse.length(); odjwewhejqse++) {
			odjwewhejsne+=odjwevhejse.charAt(odjwewhejqse);
		}
		return odjwewhejsne;
	}
}
