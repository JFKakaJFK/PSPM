package com.discussion.ex2;

import java.util.Arrays;
import java.util.List;

import com.discussion.ex1.Employee;

public class SalaryCalculator {

	public static void main(String[] args) {
		Employee e0 = new Employee(0,"Matthew","Johnson",121.3212);
		Employee e1 = new Employee(1,"Gerald","Coleman",1432.321);
		Employee e2 = new Employee(2,"Janet","Gonzales",11.111);
		
		List<Employee> employees = Arrays.asList(e0,e1,e2);

		double salaryAmount = 0.0;		
		for(Employee employee : employees){
			salaryAmount+=employee.getSalary();
		}
		
		System.out.println("Salary amount: "+salaryAmount);
		
	}

}
