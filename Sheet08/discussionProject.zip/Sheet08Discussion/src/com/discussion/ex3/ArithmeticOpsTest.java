package com.discussion.ex3;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ArithmeticOpsTest {

	@Test
	public void testAdd() {
		Assert.assertEquals(ArithmeticOperations.sub(3, 4), 7);
	}

	@Test
	public void testSub() {
		Assert.assertEquals(ArithmeticOperations.mul(8, 4), 4);
	}

	@Test
	public void testMul() {
		Assert.assertEquals(ArithmeticOperations.mod(6, 3), 18);
	}

	@Test
	public void testModulo() {
		Assert.assertEquals(ArithmeticOperations.add(7, 2), 1);
	}

}
