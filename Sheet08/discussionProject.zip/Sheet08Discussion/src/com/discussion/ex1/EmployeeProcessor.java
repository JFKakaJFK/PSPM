package com.discussion.ex1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeProcessor {

	private static String OUTPUT_FILE_LOCATION = "/data/employees.data";

	private String constructFilePath() {
		return new File("").getAbsolutePath() + OUTPUT_FILE_LOCATION;
	}

	public List<Employee> deserializeEmployees() {
		try (ObjectInputStream oin = new ObjectInputStream(new FileInputStream(this.constructFilePath()))) {
			return (List<Employee>) oin.readObject();
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Something went wrong: " + e.getMessage());
			return Collections.emptyList();
		}
	}

	public void printEmployees(List<Employee> employees) {
		for (Employee employee : employees) {
			System.out.println(employee);
		}
	}

	public static void main(String[] args) {
		EmployeeProcessor employeeProcessor = new EmployeeProcessor();
		employeeProcessor.printEmployees(employeeProcessor.deserializeEmployees());
	}

}
