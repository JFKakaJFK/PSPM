package com.self.ex2.employees;

public class Employee extends Trainee{

	public int id;
	public String firstname;
	public String lastname;
	public double baseSalary;
	public boolean hasBachelor;
	public boolean hasMaster;
	public boolean isMaintenanceMan;
	public boolean isManager;
	public double bachelorBonus;
	public double masterBonus;
	public double experienceBonus;
	public int yearsWorkingForCompany;

	/**
	 * Das ist ein Konstruktor für einen Angestellten. Es werden viele Parameter
	 * übergeben.
	 */
	public Employee(int id, String firstname, String lastname, double baseSalary, boolean hasBachelor,
			boolean hasMaster, boolean isMaintenanceMan, boolean isManager, double bachelorBonus, double masterBonus,
			double experienceBonus) {
		super(id, firstname, lastname, baseSalary);
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.baseSalary = baseSalary;
		this.hasBachelor = hasBachelor;
		this.hasMaster = hasMaster;
		this.isMaintenanceMan = isMaintenanceMan;
		this.isManager = isManager;
		this.bachelorBonus = bachelorBonus;
		this.masterBonus = masterBonus;
		this.experienceBonus = experienceBonus;
	}

	/*
	 * Diese Methode berechnet das Gehalt
	 */
	public static String BERECHNE_GEHALT(int id, String firstname, String lastname, boolean hasBachelor,
			boolean hasMaster, boolean isMaintenanceMan, boolean isManager, int yearsWorkingForCompany) {

		double gehalt = 0.0;

		if (hasBachelor && !hasMaster && !isManager && !isMaintenanceMan) {
			gehalt = 1200 + 600;
		}
		if (!hasBachelor && hasMaster && !isManager && !isMaintenanceMan) {
			gehalt = 1200 + 900;
		}
		if (!hasBachelor && !hasMaster && isManager && !isMaintenanceMan) {
			gehalt = 1200 + 2400 - 1200;
		}
		if (!hasBachelor && !hasMaster && !isManager && isMaintenanceMan) {
			gehalt = 1200 + 300;
		}

		if (isManager) {
			gehalt = 1200 + 2400 - 1200 + yearsWorkingForCompany * 50;
		}
		return gehalt + " EUR";
	}

	
	@Override
	public String toString() {
		return super.toString();
	}
}
