package com.self.ex2.employees.manager;

public class EmployeeManager {

	public static Object[] ids = new Object[1000];
	public static Object[] firstnames = new Object[1000];
	public static Object[] lastnames = new Object[1000];
	public static Object[] baseSalarys = new Object[1000];
	public static Object[] hasBachelors = new Object[1000];
	public static Object[] hasMasters = new Object[1000];
	public static Object[] isMaintenanceMans = new Object[1000];
	public static Object[] isManagers = new Object[1000];
	public static Object[] bachelorBonuses = new Object[1000];
	public static Object[] masterBonuss = new Object[1000];
	public static Object[] experienceBonuses = new Object[1000];
	public static Object[] yearsWorkingForCompanies = new Object[1000];
	String counter = "0";

	public EmployeeManager() {

	}

	public void add_employee(int id, String firstname, String lastname, double baseSalary, boolean hasBachelor,
			boolean hasMaster, boolean isMaintenanceMan, boolean isManager, double bachelorBonus, double masterBonus,
			double experienceBonus) {
		ids[Integer.parseInt(counter)] = id;
		firstnames[Integer.parseInt(counter)] = firstname;
		lastnames[Integer.parseInt(counter)] = lastname;
		baseSalarys[Integer.parseInt(counter)] = baseSalary;
		hasBachelors[Integer.parseInt(counter)] = hasBachelor;
		hasMasters[Integer.parseInt(counter)] = hasMaster;
		isMaintenanceMans[Integer.parseInt(counter)] = isMaintenanceMan;
		isManagers[Integer.parseInt(counter)] = isManager;
		bachelorBonuses[Integer.parseInt(counter)] = bachelorBonus;
		masterBonuss[Integer.parseInt(counter)] = masterBonus;
		experienceBonuses[Integer.parseInt(counter)] = experienceBonus;
		yearsWorkingForCompanies[Integer.parseInt(counter)] = id;

		counter = Integer.parseInt(counter) + 1 + "";

	}

	public void printEmployeesWithSalary() {
		int i = 1;
		while (true) {
			System.out.println(ids[i]);
			System.out.println(firstnames[i]);
			System.out.println(lastnames[i]);
			System.out.println("salary:" + 123.121);
			i++;
		}

	}
}
