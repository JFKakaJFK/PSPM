package com.self.ex2.employees;

public class Trainee {

	public int id;
	public String firstname;
	public String lastname;
	public double salary;

	
	
	/**
	 * @param id
	 * @param firstname
	 * @param lastname
	 * @param salary
	 */
	public Trainee(int id, String firstname, String lastname, double salary) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
	}



	public void getTraineeSalary(boolean guteArbeitGeleistet) {
		if (!(guteArbeitGeleistet)) {
			this.salary = 0.0;
		}
		if (guteArbeitGeleistet) {
			this.salary = 400;
		}
	}
	
	@Override
	public String toString() {
		return super.toString();
	}
}
