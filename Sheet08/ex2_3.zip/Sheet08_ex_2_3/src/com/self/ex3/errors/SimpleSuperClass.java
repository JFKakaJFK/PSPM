package com.self.ex3.errors;

public class SimpleSuperClass {

	private String name="John Doe";
	
	public void doSomething(){
		System.out.println(name);
	}
}
