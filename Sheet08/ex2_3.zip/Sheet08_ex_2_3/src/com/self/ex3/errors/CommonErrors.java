package com.self.ex3.errors;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommonErrors {

	private List<String> someStrings;
	private Map<SimpleClass, String> map = new HashMap<>();
	public int anIntProperty;
	public static final int my_constant=131;
	
	public static class A {
		private int prop0;
		private String prop1;
	}
	
	public static class B {
		private int prop0;
		private String prop1;
	}
	
	public static class C {
		private int prop0;
		private String prop1;
	}	
	
	public boolean isWithinList(String entry){
		boolean found=false;
		for(int i=1; i<=someStrings.size(); i++){
			if(someStrings.get(i)==entry){
				found=true;
				break;
			}
		}
		if(found)
			return true;
		else
			return false;
	}
	
	
	public boolean mapContains(SimpleClass clazz){
		return this.map.containsKey(clazz);
	}
	
	
	public void readSomething(){
		try {
			BufferedReader bi = new BufferedReader(new FileReader(new File("")));
			String line="";
			while((line=bi.readLine())!=null){
				
			}
		} catch (Exception e) {
			//:P
		}
	}
	

	
}
