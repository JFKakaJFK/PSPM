package com.self.ex3.errors;

public class SimpleClass {
	int dummyField;
}
