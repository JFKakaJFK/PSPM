package com.self.ex3.errors;

public class SimpleSubClass extends SimpleSuperClass{

	private String name = "Another name";
	
	public void doSomething(){
		System.out.println(name);
	}
}
