public class Student extends Person {
  
  int studentID;

  public Student(String firstName, String lastName, int studentID) {
    super(firstName, lastName);
    this.studentID = studentID;
  }

  @Override
  public void greet(Person other){
    System.out.println("A student named " + this.getFirstName() + " " + this.getLastName() + " says hello to " + other.getFirstName() + " " + other.getLastName());
  }

  public static void main(String[] args){
    Person person = new Person("Paul", "Person");
    Student student = new Student("Sam", "Student", 1);
    person.greet(student);
    student.greet(person);
  }
}
