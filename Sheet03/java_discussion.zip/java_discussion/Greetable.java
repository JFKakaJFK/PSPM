public Interface Greetable{

  public void greetMorning();

  public void greetNoon();

  public void greetEvening();

  public void greetNight();

}
