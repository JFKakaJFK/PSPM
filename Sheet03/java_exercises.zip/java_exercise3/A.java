package sheet03.inheritance.exercise3;

public class A {
	public void print(A a) {
		System.out.println("A 1");
	}
}
