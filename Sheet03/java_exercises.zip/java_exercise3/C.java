package sheet03.inheritance.exercise3;

public class C extends B {
	public void print(A a) {
		System.out.println("C 1");
	}

	public void print(B b) {
		System.out.println("C 2");
	}

	public void print(C c) {
		System.out.println("C 3");
	}
}
