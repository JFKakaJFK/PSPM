package sheet03.inheritance.exercise3;

public class B extends A {
	public void print(A a) {
		System.out.println("B 1");
	}

	public void print(B b) {
		System.out.println("B 2");
	}
}
