package sheet03.inheritance.exercise2;

public interface ICredentialChecker {

	/**
	 * Checks if the given credential is valid
	 * 
	 * @param toCheck
	 *            the credential to check
	 * @return <code>true</code> if the credential is valid, <code>false</code> otherwise
	 */
	boolean check(Credential toCheck);

}
