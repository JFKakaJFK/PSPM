package sheet03.inheritance.exercise2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CheckerTest {

	private static final char[] alphaNumericalChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
	private static final char[] specialChars = "!$%&?_".toCharArray();

	public static void main(String[] args) {
		List<Credential> toCheckCredentials = new ArrayList<>();
		toCheckCredentials.add(new Credential("abc", "12345"));
		toCheckCredentials.add(new Credential("user0", "pa$$$word"));
		toCheckCredentials.add(new Credential("my8user", "12345"));
		toCheckCredentials.add(new Credential("1my8user", "1c2d3$$4?5"));
		toCheckCredentials.add(new Credential("admin", "232???§§_"));
		toCheckCredentials.add(new Credential("adMin", "232???§§_"));
		toCheckCredentials.add(new Credential("testuser", "!!!!"));
		toCheckCredentials.add(new Credential("test_user", "!!abcde$!"));
		toCheckCredentials.add(new Credential("testuser2", "this is a very long password that should exceed 16 characters"));
		toCheckCredentials.add(new Credential("superadmin", "this is a very long password that should exceed 16 characters"));
		toCheckCredentials.add(new Credential("testuser", null));
		toCheckCredentials.add(new Credential(null, "valid%%%%password"));
		toCheckCredentials.add(new Credential(null, null));

		// create checkers

		...
		
		// build connections and create finalChecker

		ICredentialChecker finalChecker = ...

		for(Credential c : toCheckCredentials) {
			System.out.println("checking credential: " + c + ": " + finalChecker.check(c));
		}
	}
}
