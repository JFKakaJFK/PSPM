package sheet01.oo.discussion;

import java.util.ArrayList;
import java.util.List;

public class Island {
	private String name;
	private double size;
	private int inhabitants;
	private List<Ferry> ferries = new ArrayList<>();

	public Island() {
	}

	public Island(String name, double size) {
		this.name = name;
		this.size = size;
	}

	public Island(String name, double size, int inhabitants) {
		this(name, size);
		this.inhabitants = inhabitants;
	}

	public String computeInfo() {
		return "Name: " + name + "\nGröße: " + size + " km^2\nEinwohner: " + inhabitants;
	}

	public static void main(String[] args) {
		Island island1 = new Island();
		island1.setName("Oahu");
		island1.setSize(1557);
		island1.setInhabitants(953207);
		System.out.println(island1.computeInfo());

		Island island2 = new Island("Malta", 316);
		island2.setInhabitants(433300);
		System.out.println("\n" + island2.computeInfo());

		Island island3 = new Island("Capri", 10.4, 13839);
		System.out.println("\n" + island3.computeInfo());

		// ADVANCED EXAMPLE

		// companies
		Company c1 = new Company();
		c1.setCompanyId(1);
		c1.setName("c1");

		Company c2 = new Company();
		c2.setCompanyId(21);
		c2.setName("c2");

		// cars
		Car car1 = new Car();
		car1.setCarId(1);
		car1.setBrand("car1Brand");
		car1.setModel("car1Model");
		car1.setCompany(c1);

		Car car2 = new Car();
		car2.setCarId(2);
		car2.setBrand("car2Brand");
		car2.setModel("car2Model");
		car2.setCompany(c1);

		Car car3 = new Car();
		car3.setCarId(3);
		car3.setBrand("car3Brand");
		car3.setModel("car3Model");
		car3.setCompany(c2);

		// ferries
		Ferry ferry1 = new Ferry(1, 100);
		ferry1.getCars().add(car1);
		ferry1.getCars().add(car3);

		Ferry ferry2 = new Ferry(2, 50);
		ferry2.getCars().add(car1);
		ferry2.getCars().add(car2);
		ferry2.getCars().add(car3);

		// connect ferries to islands

		island1.saveFerry(ferry1);
		island2.saveFerry(ferry2);
	}

	public void saveFerry(Ferry ferry) {
		ferries.add(ferry);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public double getInhabitants() {
		return inhabitants;
	}

	public void setInhabitants(int inhabitants) {
		this.inhabitants = inhabitants;
	}

}
