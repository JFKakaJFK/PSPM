package sheet01.oo.discussion;

public class Company {
	private int companyId;
	public String name;

	public Company() {
		System.out.println("Created a new Company object");
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
