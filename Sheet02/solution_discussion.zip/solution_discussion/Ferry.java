package sheet01.oo.discussion;

import java.util.ArrayList;
import java.util.List;

public class Ferry {
	private int ferryNumber;
	private int capacity;
	private List<Car> cars;

	public Ferry(int ferryNumber, int theCapacity) {
		this.ferryNumber = ferryNumber;
		capacity = theCapacity;
		cars = new ArrayList<>();
	}

	public int getFerryNumber() {
		return ferryNumber;
	}

	public void setFerryNumber(int ferryNumber) {
		this.ferryNumber = ferryNumber;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public List<Car> getCars() {
		return cars;
	}

	public void setCars(List<Car> cars) {
		this.cars = cars;
	}

}
