import java.util.List;

public class Main {

	public static void main(String[] args) {
		CitizenRepository repo = new RandomCitizenRepository();
		List<Citizen> citizens = repo.loadCitizens();
		
		System.out.println(citizens);
		
		System.out.println("Average age: " + Statistics.getAverageAge(citizens));
		System.out.println("Age histogram: " + Statistics.getAgeHistogram(citizens));
		System.out.println("Average income: " + Statistics.getAverageYearlyIncome(citizens));
		System.out.println("Citizens per occupation: " + Statistics.getCitizensPerOccupation(citizens));
		System.out.println("Avg. income per occupation: " + Statistics.getAvgIncomePerOccupation(citizens));
		System.out.println("Top 5 earners: " + Statistics.getTopEarners(citizens, 5));
	}

}
