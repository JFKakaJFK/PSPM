import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Test class for Statistics.
 */
public class StaticticsTest {
	@Test
	public void getAverageAgeNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 10, "", 0.0));
		l.add(new Citizen("", "", 20, "", 0.0));
		l.add(new Citizen("", "", 30, "", 0.0));
		double avgAge = Statistics.getAverageAge(l);
		
		Assert.assertEquals(avgAge, 20.0);
	}
	@Test
	public void getAverageIncomeNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 0, "", 10.0));
		l.add(new Citizen("", "", 0, "", 20.0));
		l.add(new Citizen("", "", 0, "", 30.0));
		double avgAge = Statistics.getAverageYearlyIncome(l);
		
		Assert.assertEquals(avgAge, 20.0);
	}
	@Test
	public void getCitizensPerOccupationNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 0, "Student", 0.0));
		l.add(new Citizen("", "", 0, "Student", 0.0));
		l.add(new Citizen("", "", 0, "Doctor", 0.0));
		Map<String, Long> res = Statistics.getCitizensPerOccupation(l);
		
		Assert.assertEquals(res.size(), 2);
		Assert.assertEquals((long)res.get("Student"), 2L);
		Assert.assertEquals((long)res.get("Doctor"), 1L);
	}
	@Test
	public void getAvgIncomePerOccupationNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 0, "Student", 100.0));
		l.add(new Citizen("", "", 0, "Student", 200.0));
		l.add(new Citizen("", "", 0, "Doctor", 1000.0));
		Map<String, Double> res = Statistics.getAvgIncomePerOccupation(l);
		
		Assert.assertEquals(res.size(), 2);
		Assert.assertEquals((double)res.get("Student"), 150.0);
		Assert.assertEquals((double)res.get("Doctor"), 1000.0);
	}
	@Test
	public void getAgeHistogramNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 17, "", 0.0));
		l.add(new Citizen("", "", 18, "", 0.0));
		l.add(new Citizen("", "", 22, "", 0.0));
		l.add(new Citizen("", "", 21, "", 0.0));
		l.add(new Citizen("", "", 24, "", 0.0));
		l.add(new Citizen("", "", 66, "", 0.0));
		Map<String, Long> res = Statistics.getAgeHistogram(l);
		
		Assert.assertEquals(res.size(), 3);
		Assert.assertEquals((long)res.get("15 to 19"), 2L);
		Assert.assertEquals((long)res.get("20 to 24"), 3L);
		Assert.assertEquals((long)res.get("65 to 69"), 1L);
	}
	@Test
	public void getTopEarnersNormal() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("A", "", 0, "", 1000.0));
		l.add(new Citizen("B", "", 0, "", 200.0));
		l.add(new Citizen("C", "", 0, "", 1300.0));
		l.add(new Citizen("D", "", 0, "", 160.0));
		l.add(new Citizen("E", "", 0, "", 0.0));
		l.add(new Citizen("F", "", 0, "", 1100.0));
		List<Citizen> res = Statistics.getTopEarners(l, 3);
		
		Assert.assertEquals(res.size(), 3);
		Assert.assertEquals(res.get(0).getFirstname(), "C");
		Assert.assertEquals(res.get(1).getFirstname(), "F");
		Assert.assertEquals(res.get(2).getFirstname(), "A");
	}
	
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAverageAgeNull() {
		Statistics.getAverageAge(null);
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAverageIncomeNull() {
		Statistics.getAverageYearlyIncome(null);
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getCitizensPerOccupationNull() {
		Statistics.getCitizensPerOccupation(null);
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAvgIncomePerOccupationNull() {
		Statistics.getAvgIncomePerOccupation(null);
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAgeHistogramNull() {
		Statistics.getAgeHistogram(null);
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getTopEarnersNull() {
		Statistics.getTopEarners(null, 3);
	}
	
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAverageAgeEmpty() {
		Statistics.getAverageAge(new ArrayList<Citizen>());
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAverageIncomeEmpty() {
		Statistics.getAverageYearlyIncome(new ArrayList<Citizen>());
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getCitizensPerOccupationEmpty() {
		Statistics.getCitizensPerOccupation(new ArrayList<Citizen>());
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAvgIncomePerOccupationEmpty() {
		Statistics.getAvgIncomePerOccupation(new ArrayList<Citizen>());
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getAgeHistogramEmpty() {
		Statistics.getAgeHistogram(new ArrayList<Citizen>());
	}
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getTopEarnersEmpty() {
		Statistics.getTopEarners(new ArrayList<Citizen>(), 3);
	} 
	
	@Test(expectedExceptions= {IllegalArgumentException.class})
	public void getTopEarnersTooSmall() {
		List<Citizen> l = new ArrayList<Citizen>();
		l.add(new Citizen("", "", 0, "", 0.0));
		Statistics.getTopEarners(l, 3);
	}
}
