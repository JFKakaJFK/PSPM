import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A class for calculating various citizen statistics.
 */
public class Statistics {
	private static void CheckIfNullOrEmpty(List<Citizen> citizens) {
		if (citizens == null || citizens.size() < 1) {
			throw new IllegalArgumentException("citizens may not be null or empty");
		}
	}
	
	/**
	 * Calculates the average age of all citizens in the given list.
	 * @param citizens The list of citizens for which the average age should by calculated.
	 * @return The average age.
	 */
	public static double getAverageAge(List<Citizen> citizens) {
		CheckIfNullOrEmpty(citizens);
		
		double ageSum = 0.0;
		for (Citizen c : citizens) {
			ageSum += c.getAge();
		}
		
		return ageSum / citizens.size();
	}
	
	/**
	 * Calculates the average income of all citizens in the given list.
	 * @param citizens The list of citizens for which the average income should by calculated.
	 * @return The average income.
	 */
	public static double getAverageYearlyIncome(List<Citizen> citizens) {
		CheckIfNullOrEmpty(citizens);
		
		double incomeSum = 0.0;
		for (Citizen c : citizens) {
			incomeSum += c.getYearlyIncome();
		}
		
		return incomeSum / citizens.size();
	}
	
	/**
	 * Calculates the number of citizens per occupation.
	 * @param citizens The list of citizens.
	 * @return The number of citizens per occupation, as a Map<String, Integer>.
	 */
	public static Map<String, Long> getCitizensPerOccupation(List<Citizen> citizens) {
		CheckIfNullOrEmpty(citizens);
		Map<String, Long> result = new HashMap<String, Long>();
		
		for (Citizen c : citizens) {
			if (result.containsKey(c.getOccupation())) {
				result.put(c.getOccupation(), result.get(c.getOccupation()) + 1);
			}
			else {
				result.put(c.getOccupation(), 1L);
			}
		}
		
		return result;
	}
	
	/**
	 * Calculates the average income per occupation.
	 * @param citizens The list of citizens.
	 * @return The average income per occupation, as a Map<String, Double>.
	 */
	public static Map<String, Double> getAvgIncomePerOccupation(List<Citizen> citizens) {
		CheckIfNullOrEmpty(citizens);
		Map<String, Double> result = new HashMap<String, Double>();
		
		//Count citizens per occupation
		Map<String, Long> counts = getCitizensPerOccupation(citizens);
		
		//Sum income per occupation
		for (Citizen c : citizens) {
			if (result.containsKey(c.getOccupation())) {
				result.put(c.getOccupation(), result.get(c.getOccupation()) + c.getYearlyIncome());
			}
			else {
				result.put(c.getOccupation(), c.getYearlyIncome());
			}
		}
		
		//Divide to get average
		for (Map.Entry<String, Double> e : result.entrySet()) {
			long count = counts.get(e.getKey());
			e.setValue(e.getValue() / count);
		}
		
		return result;
	}
	
	/**
	 * Calculates an age histogram for the given list of citizens.
	 * @param citizens The list of citizens.
	 * @return An age histogram, as a Map<String, Integer>, where the String represents an age group in intervals of 5 years.
	 */
	public static Map<String, Long> getAgeHistogram(List<Citizen> citizens) {
		CheckIfNullOrEmpty(citizens);
		Map<String, Long> result = new HashMap<String, Long>();
		
		for (Citizen c : citizens) {
			int ageBin = c.getAge() / 5;
			String ageGroup = (ageBin * 5) + " to " + (ageBin * 5 + 4);
			
			if (result.containsKey(ageGroup) ) {
				result.put(ageGroup, result.get(ageGroup) + 1);
			}
			else {
				result.put(ageGroup, 1L);
			}
		}
		
		return result;
	}
	
	/**
	 * Calculates the n top earners in the given list of citizens.
	 * @param citizens The list of citizens.
	 * @param n How many top earners should be retrieved.
	 * @return The List of the n top earners, sorted in descending order of income.
	 */
	public static List<Citizen> getTopEarners(List<Citizen> citizens, int n) {
		CheckIfNullOrEmpty(citizens);
		if (citizens.size() < n) {
			throw new IllegalArgumentException("citizens");
		}
		
		List<Citizen> result = new ArrayList<Citizen>(n);
		
		result.addAll(citizens);
		result.sort(new Comparator<Citizen>() {
			@Override
			public int compare(Citizen arg0, Citizen arg1) {
				//Sort descending - switch order of compare arguments!
				return Double.compare(arg1.getYearlyIncome(), arg0.getYearlyIncome());
			}
		});
		
		return result.subList(0, n);
	}
}
