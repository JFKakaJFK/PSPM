package pm.midterm2.group1.exercise1;

import java.util.ArrayList;
import java.util.HashSet;

public class MetaInfoCollectionTest {
	public static void main(String[] args) {
		MetaInfoCollection<Integer, String> testCollection1 = new MetaInfoCollection<>(new ArrayList<Integer>());
		testCollection1.add(1, "Meta info 1");
		testCollection1.add(2, "Meta info 2");
		testCollection1.add(3, "Meta info 3");

		check(testCollection1.getElement("Meta info 3"), 3);
		check(testCollection1.getMetaInfo(1), "Meta info 1");

		MetaInfoCollection<String, Double> testCollection2 = new MetaInfoCollection<>(new HashSet<String>());
		testCollection2.add("A", 1.1);
		testCollection2.add("B", 2.2);
		testCollection2.add("C", 3.3);

		check(testCollection2.getElement(3.3), "C");
		check(testCollection2.getMetaInfo("A"), 1.1);
		check(testCollection2.getElement(100.0), null);
		check(testCollection2.getMetaInfo("D"), null);
	}

	private static void check(Object current, Object expected) {
		if((expected == null && current == null) || (expected != null && expected.equals(current))) {
			System.out.println("check: ok");
		}
		else {
			System.out.println("check: failed");
		}
	}
}
