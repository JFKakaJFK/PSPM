package pm.midterm2.group1.exercise2;

public interface NumberGenerator {
	int nextNumber();
	int previousNumber();
}
